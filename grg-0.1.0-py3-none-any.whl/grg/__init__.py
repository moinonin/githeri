"""
GRG (Geometric Reasoning Governor) — Real-time structural integrity monitoring for LLM inference.

A Python package for monitoring and governing the structural integrity of LLM outputs
during token generation using Alpha-Drift Velocity (V_alpha) tracking.

Key Components:
- AlphaMomentumTracker: Core GRG class for real-time EMA-smoothed alpha tracking
- SGO Metrics: Structural Geometry Optimization metrics for evaluating binary-outcome systems
- Configuration: Profile-based configuration for different sensitivity requirements

Usage:
    from grg import AlphaMomentumTracker, evaluate_structural_geometry
    from grg.config import get_config

    # Real-time GRG tracking
    tracker = AlphaMomentumTracker()
    for token_logprob in token_stream:
        alpha = compute_structural_alpha(token_logprob)
        tracker.push(alpha)
        stats = tracker.get_stats()
        if stats["is_collapsing"]:
            # Trigger thermal damping or e-stop
            pass

    # Offline SGO evaluation
    results = evaluate_structural_geometry(positive_outcomes, negative_outcomes)
    print(f"Structural Alpha: {results['structural_alpha']:.4f}")
    print(f"Ranking Score: {results['ranking_score']:.4f}")
"""

from grg.config import get_config
from grg.metrics import (
    # Ranking Profiles
    RANKING_PROFILES,
    # Trackers (GRG Core)
    AlphaMomentumTracker,
    StructuralTracker,
    # Utility
    apply_utility_transformation,
    calculate_cofactor_matrix,
    # Entropy & Probability
    calculate_entropy,
    calculate_moment_sgo_metrics,
    # Structural Metrics
    calculate_normalized_structure_metrics,
    calculate_positive_alpha_penalty,
    calculate_probability_sgo_matrix,
    # Ranking & Diagnostics
    calculate_ranking_score,
    calculate_regime_aware_ideal,
    calculate_sgo_divergence,
    compute_distributional_concentration,
    # Core SGO Matrix Functions
    compute_sgo_matrix,
    # Per-token alpha extraction
    compute_structural_alpha,
    evaluate_balance_diagnostics,
    evaluate_cofactors_norm_diff_diagnostics,
    # Distributional Analysis
    evaluate_distributional_geometry,
    evaluate_structural_geometry,
    extract_matrix_alpha,
)

__version__ = "0.1.0"

__all__ = [
    # Core SGO Matrix Functions
    "compute_sgo_matrix",
    "calculate_moment_sgo_metrics",
    "evaluate_structural_geometry",
    # Per-token alpha extraction
    "compute_structural_alpha",
    # Structural Metrics
    "calculate_normalized_structure_metrics",
    "extract_matrix_alpha",
    "calculate_cofactor_matrix",
    "calculate_regime_aware_ideal",
    # Ranking & Diagnostics
    "calculate_ranking_score",
    "calculate_positive_alpha_penalty",
    "evaluate_balance_diagnostics",
    "evaluate_cofactors_norm_diff_diagnostics",
    # Entropy & Probability
    "calculate_entropy",
    "calculate_probability_sgo_matrix",
    "calculate_sgo_divergence",
    # Distributional Analysis
    "evaluate_distributional_geometry",
    "compute_distributional_concentration",
    # Utility
    "apply_utility_transformation",
    # Trackers (GRG Core)
    "AlphaMomentumTracker",
    "StructuralTracker",
    # Ranking Profiles
    "RANKING_PROFILES",
    # Config
    "get_config",
]
