"""Centralized configuration loader for GRG (Geometric Reasoning Governor)."""

import json
import os
from pathlib import Path
from typing import Any

DEFAULT_CONFIG_PATH = Path("config/grg-config.json")


def resolve_config_path() -> Path:
    """Find the config file regardless of current working directory."""
    env_path = os.getenv("GRG_CONFIG")
    if env_path:
        return Path(env_path)

    # 1. Try relative to CWD
    cwd_path = Path.cwd() / DEFAULT_CONFIG_PATH
    if cwd_path.exists():
        return cwd_path

    # 2. Try relative to this file (grg/config.py -> ./grg-config.json in same dir)
    module_path = Path(__file__).parent / "grg-config.json"
    if module_path.exists():
        return module_path

    # 3. Try relative to this file's parent (grg/config.py ->
    # ../config/grg-config.json for installed packages)
    package_path = Path(__file__).parent / "config" / "grg-config.json"
    if package_path.exists():
        return package_path

    # 4. Try package data location (for development mode from src/)
    dev_path = Path(__file__).parent.parent / "config" / "grg-config.json"
    if dev_path.exists():
        return dev_path

    return DEFAULT_CONFIG_PATH


def load_config() -> dict[str, Any]:
    """Load the GRG configuration from file or return defaults."""
    # Global Defaults
    config = {
        "global": {
            "ranking_profile": "conservative",
            "grg": {
                "window_size": 20,
                "ema_weight": 0.3,
                "warmup_steps": 50,
                "lr_slash_factor": 0.1,
                "lr_restore_factor": 1.0,
                "thermal_damping_min_temp": 0.01,
                "e_stop_horizon": 5,
                "collapse_v_alpha_threshold": -0.02,
                "stability_v_alpha_threshold": 0.005,
                "trajectory_window_size": 500,
                "trajectory_window_step": 50,
                "v_alpha_panic_threshold": -0.02,
                "alpha_safety_floor": 0.10,
            },
        },
        "profiles": {},
    }

    config_path = resolve_config_path()

    if config_path.exists():
        try:
            with open(config_path) as f:
                user_config = json.load(f)
                if "global" in user_config or "profiles" in user_config:
                    # New hierarchical format
                    if "global" in user_config:
                        config["global"].update(user_config["global"])
                    if "profiles" in user_config:
                        config["profiles"].update(user_config["profiles"])
                else:
                    # Legacy flat format - merge into global
                    config["global"].update(user_config)
        except Exception:
            # Silently fall back to defaults if config fails to load
            pass

    return config


# Global config instance
_config_data = load_config()


class ConfigWrapper:
    """Helper to access config with legacy support and profile awareness."""

    def __init__(self, data: dict[str, Any]):
        self._data = data

    def get(self, key: str, default: Any = None) -> Any:
        """Legacy access to global settings."""
        return self._data["global"].get(key, default)

    def get_profile(self, profile_name: str) -> dict[str, Any]:
        """Get profile merged with global defaults."""
        profile = self._data["global"].copy()
        profile.update(self._data["profiles"].get(profile_name, {}))
        return profile

    def get_grg_config(self, profile_name: str | None = None) -> dict[str, Any]:
        """Get GRG settings merged: global.grg -> profile.grg."""
        grg = dict(self._data["global"].get("grg", {}))
        if profile_name:
            profile_grg = self._data["profiles"].get(profile_name, {}).get("grg", {})
            grg.update(profile_grg)
        return grg

    def __getitem__(self, key: str) -> Any:
        return self._data["global"][key]


get_config = ConfigWrapper(_config_data)
